import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { RestdbService } from './shared/restdb.service';
import { ShribService } from './shared/shrib.service';

import { AppComponent } from './app.component';
import { TodoComponent } from './todo/todo.component';
import { ShribComponent } from './shrib/shrib.component';
import { TempComponent } from './temp/temp.component';


const appRoutes : Routes = [
  { path: '**', component: TempComponent}
];



@NgModule({
  declarations: [
    AppComponent,
    TodoComponent,
    ShribComponent,
    TempComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [RestdbService, ShribService],
  bootstrap: [AppComponent]
})
export class AppModule { }
