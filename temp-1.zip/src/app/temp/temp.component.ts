import { Component, OnInit } from '@angular/core';
import { ShribService } from './../shared/shrib.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-temp',
  templateUrl: './temp.component.html',
  styleUrls: ['./temp.component.css']
})
export class TempComponent implements OnInit {

  _changeInterval = null;
  bodyData : any = { 'entry': '' , 'url' : ''}

  constructor(
    private shribService: ShribService,
    private router: Router,
    private route: ActivatedRoute
  ) {

    if (this.router.url === '/') {
      console.log("Accessed Home Page")
      //New entry is created When Accessed Home Page
      this.shribService.newDataEntry().subscribe((data: any) => this.nextStep(data))
    }
    else {
      //checking the URL
      this.shribService.findDataEntry(this.router.url).subscribe((data: any) => {
        if (data.length === 0) {
          console.log("No url is present with this Route")
          //If no route is present then adding the route
          this.shribService.newDataEntryWithPath(this.router.url).subscribe(
            (data): any => {
              this.bodyData = data;
            })
        }
        else {
          console.log("Url is present In DB")
          console.log(data[0]);
          this.bodyData = data[0]
        }
      })
    }

  }

  ngOnInit() {
  }

  nextStep(x) {
    //Adding the URL Info for the request
    console.log("Adding the URL info for the newely created Entry")
    this.shribService.putURLDataInNewCreatedDataEntry(x).subscribe((data: any) => {
      this.bodyData = data
      this.router.navigate([x._id]);
    })
  }

  edited(x){
    clearTimeout(this._changeInterval)
    this._changeInterval = setTimeout(() => {
      this.shribService.putTheEditedEntry(x).subscribe((data : any) => console.log(data))
      clearTimeout(this._changeInterval)
    }, 3000);
  }

}
