import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'cache-control': 'no-cache',
    'apikey': '5c67d7daad19dc08b020d498'
  })
};


@Injectable({
  providedIn: 'root'
})

export class RestdbService {

  readonly baseURL = 'https://temptodo-5617.restdb.io/rest/todo';

  constructor(private httpClient: HttpClient) {
    this.httpClient = httpClient;
  }

  getInfo() {
    return this.httpClient.get(this.baseURL, httpOptions)
  }

  putInfo(y){
    let payloadBody = { title : '' , completed : 0 }

    payloadBody.title = y.title;
    payloadBody.completed = y.completed;

    let currentRequestURL = this.baseURL+'/'+y._id;

    console.log("Post URL : " , currentRequestURL)
    console.log("Pay load Body" , payloadBody)

    return this.httpClient.put(currentRequestURL, payloadBody, httpOptions)
  }



}



