import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'cache-control': 'no-cache',
    'apikey': '5c67d7daad19dc08b020d498'
  })
};

@Injectable({
  providedIn: 'root'
})

export class ShribService {
  readonly shribBaseURL = 'https://temptodo-5617.restdb.io/rest/shrib';

  constructor(private httpClient: HttpClient) { }

  newDataEntry(){
    let payLoadBody = {entry : '', url : ''}

    console.log("New Entry with Payload" , payLoadBody)

    return this.httpClient.post(this.shribBaseURL, payLoadBody, httpOptions)
  }

  putURLDataInNewCreatedDataEntry(id){
    let payloadBody = {entry : '', url : id._id}
    let currentRequestURL = this.shribBaseURL + '/' + id._id;

    console.log("Adding Id for the New Entry" , payloadBody)

    return this.httpClient.put(currentRequestURL, payloadBody, httpOptions)
  }

  findDataEntry(y){
    y = y.substr(1)
    let tempURL = this.shribBaseURL + '?q={"url":"'+y+'"}'
    
    console.log("Finding the Entry for the URL :", tempURL );

    return this.httpClient.get(tempURL , httpOptions)
  }

  newDataEntryWithPath(y){
    let tempPath = y.substr(1)
    let tempPayLoad = {entry : '', url: tempPath}

    console.log("New Post Request with the Pay Load data", tempPayLoad)

    return this.httpClient.post(this.shribBaseURL, tempPayLoad, httpOptions)
  }

  putTheEditedEntry(y){

    let payloadBody = { entry: '', url : ''}
    payloadBody.entry = y.entry;
    payloadBody.url = y.url;

    let currentRequestURL = this.shribBaseURL+'/'+y._id;

    console.log("PUT Request");

    return this.httpClient.put(currentRequestURL, payloadBody, httpOptions)
  }


}
