
import { Component, OnInit } from '@angular/core';
import { RestdbService } from './../shared/restdb.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  tempFullData

  constructor(private dbservice : RestdbService) {
    this.dbservice.getInfo().subscribe((data : any) => this.doTheseThings(data));
   }

  ngOnInit() {
  }

  doTheseThings(x){
    this.tempFullData = x;
    console.log(x);
  }

  checkValue(event: any , item){
    item.completed = ( event == true ? 1 : 0 )
    this.dbservice.putInfo(item).subscribe((data : any) => console.log(data))
 }
}
