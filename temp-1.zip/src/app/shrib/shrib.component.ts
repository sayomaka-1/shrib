
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ShribService } from './../shared/shrib.service';


@Component({
  selector: 'app-shrib',
  templateUrl: './shrib.component.html',
  styleUrls: ['./shrib.component.css']
})
export class ShribComponent implements OnInit {

  constructor() {
    
   }

  ngOnInit() {
  }


}
